import random

def triRecupIndices(tableau : list) -> list:
    tableauIndice = []
    for i in range(len(tableau)):
        tableauIndice.append((tableau[i], i))
    for i in range(len(tableauIndice)):
        for j in range(i, len(tableauIndice)):
            if (tableauIndice[i][0] > tableauIndice[j][0]):
                tampon = tableauIndice[i]
                tableauIndice[i] = tableauIndice[j]
                tableauIndice[j] = tampon
    return [tableauIndice[i][1] for i in range(len(tableauIndice))]

def minRecupIndice(tableau : list, tableauInterdits : list) -> list:
    tableauIndice = []
    minimum = min(tableau)
    for i in range(len(tableau)):
        if tableau[i] == minimum and not(i in tableauInterdits):
            tableauIndice.append(i)
    return tableauIndice[random.randint(0,len(tableauIndice) - 1)]

def comptePresence(nombres : list, tableau : list) -> int:
    score = 0
    for n in nombres:
        if n in tableau:
            score += 1
    return score