import Fonctions

# ---------- ELEVES ---------- #
class Eleve:
    # ----- VARIABLES DE CLASSES ----- #
    tableauDifficultesPrimaires = []
    tableauDifficultesSecondaires = []
    tableauNombreElevesParIntervenant = [] # nbIntervenants x nbCreneaux
    nbCreneaux = 0
    nbElevesIntervCreneau = 0

    # ----- CONSTRUCTEUR & GETTERS & SETTERS ----- #
    def __init__(self, nomEleve : str, listeChoixPrimaires : list, listeChoixSecondaires : list):
        self.__nom = nomEleve
        self.__choixPrimaires = [elem - 1 for elem in listeChoixPrimaires]
        self.__choixSecondaires = [elem - 1 for elem in listeChoixSecondaires]
        self.__rencontres = [None for i in range(self.nbCreneaux)]
        for intervenant in listeChoixPrimaires:
            self.tableauDifficultesPrimaires[intervenant - 1] += 1
            self.tableauDifficultesSecondaires[intervenant - 1] += 10
        for intervenant in listeChoixSecondaires:
            self.tableauDifficultesSecondaires[intervenant - 1] += 1

    def getNom(self) -> str:
        return self.__nom
    def getListeChoixPrimaires(self) -> list:
        return self.__choixPrimaires
    def getChoixPrimaire(self, indice : int) -> int:
        assert indice < len(self.__choixPrimaires) and 0 <= indice, "L'indice ne fait pas partie du champ des possibles."
        return self.__choixPrimaires[indice]
    def getListeChoixSecondaires(self) -> list:
        return self.__choixSecondaires
    def getChoixSecondaire(self, indice : int) -> int:
        assert indice < len(self.__choixSecondaires) and 0 <= indice, "L'indice ne fait pas partie du champ des possibles."
        return self.__choixSecondaires[indice]
    def getDifficultePrimaire(self) -> int:
        return sum([self.tableauDifficultesPrimaires[intervenant] for intervenant in self.__choixPrimaires])
    def getDifficulteSecondaire(self) -> int:
        return sum([self.tableauDifficultesSecondaires[intervenant] for intervenant in self.__choixSecondaires])
    def getListeRencontres(self) -> list:
        return self.__rencontres
    def getRencontre(self, indice : int) -> int:
        assert indice < len(self.__rencontres) and 0 <= indice, "L'indice ne fait pas partie du champ des possibles."
        return self.__rencontres[indice]
    def setRencontre(self, indice : int, numeroIntervenant : int):
        assert indice < len(self.__rencontres) and 0 <= indice, "L'indice ne fait pas partie du champ des possibles."
        self.__rencontres[indice] = numeroIntervenant
    def getCreneauTroue(self) -> int:
        for i in range(len(self.__rencontres)):
            if not((self.__rencontres[i] in self.__choixPrimaires) or (self.__rencontres[i] in self.__choixSecondaires)):
                return i
    
    # ----- METHODES DE CLASSES ----- #
    @classmethod
    def trierListeElevesPrimaire(cls, listeEleves : list):
        for i in range(len(listeEleves)):
            for j in range(i+1, len(listeEleves)):
                if listeEleves[i].getDifficultePrimaire() < listeEleves[j].getDifficultePrimaire():
                    tampon = listeEleves[i]
                    listeEleves[i] = listeEleves[j]
                    listeEleves[j] = tampon
    @classmethod
    def trierListeElevesSecondaire(cls, listeEleves : list):
        for i in range(len(listeEleves)):
            for j in range(i + 1, len(listeEleves)):
                if listeEleves[i].getDifficulteSecondaire() < listeEleves[j].getDifficulteSecondaire():
                    tampon = listeEleves[i]
                    listeEleves[i] = listeEleves[j]
                    listeEleves[j] = tampon
    @classmethod
    def trierListeElevesDefavorise(cls, listeEleves : list):
        for i in range(len(listeEleves)):
            for j in range(i + 1, len(listeEleves)):
                if Fonctions.comptePresence(listeEleves[i].getListeChoixSecondaires(), listeEleves[i].getListeRencontres()) > Fonctions.comptePresence(listeEleves[j].getListeChoixSecondaires(), listeEleves[j].getListeRencontres()):
                    tampon = listeEleves[i]
                    listeEleves[i] = listeEleves[j]
                    listeEleves[j] = tampon
    @classmethod
    def setVariablesClasses(cls, nbIntervenants : int, nbCreneaux : int, nbElevesIntervCreneau : int):
        cls.nbCreneaux = nbCreneaux
        cls.tableauDifficultesPrimaires = [0 for i in range(nbIntervenants)]
        cls.tableauDifficultesSecondaires = [0 for i in range(nbIntervenants)]
        cls.tableauNombreElevesParIntervenant = [[0 for j in range(nbCreneaux)] for i in range(nbIntervenants)]
        cls.nbElevesIntervCreneau = nbElevesIntervCreneau
    
    # ----- METHODES DE RECHERCHE ----- #
    def creerRencontrePrimaire(self, numeroIntervenant : int):
        numerosCreneaux = Fonctions.triRecupIndices(self.tableauNombreElevesParIntervenant[numeroIntervenant])
        i = 0
        creneauTrouve = False
        while not creneauTrouve:
            if None == self.getRencontre(numerosCreneaux[i]):
                creneauTrouve = True
                self.tableauNombreElevesParIntervenant[numeroIntervenant][numerosCreneaux[i]] += 1
                self.setRencontre(numerosCreneaux[i], numeroIntervenant)
            else:
                i += 1
    def creerRencontreSecondaire(self, numeroIntervenant : int):
        numerosCreneaux = Fonctions.triRecupIndices(self.tableauNombreElevesParIntervenant[numeroIntervenant])
        i = 0
        creneauTrouve = False
        while not creneauTrouve:
            if self.tableauNombreElevesParIntervenant[numeroIntervenant][numerosCreneaux[i]] >= self.nbElevesIntervCreneau:
                creneauTrouve = True
            elif None == self.getRencontre(numerosCreneaux[i]):
                creneauTrouve = True
                self.tableauNombreElevesParIntervenant[numeroIntervenant][numerosCreneaux[i]] += 1
                self.setRencontre(numerosCreneaux[i], numeroIntervenant)
            else:
                i += 1
    def remplirTrous(self):
        for i in range(self.nbCreneaux):
            if self.getRencontre(i) == None:
                numeroIntervenant = Fonctions.minRecupIndice([self.tableauNombreElevesParIntervenant[intervenant][i] for intervenant in range(len(self.tableauNombreElevesParIntervenant))], self.getListeRencontres())
                self.tableauNombreElevesParIntervenant[numeroIntervenant][i] += 1
                self.setRencontre(i, numeroIntervenant)