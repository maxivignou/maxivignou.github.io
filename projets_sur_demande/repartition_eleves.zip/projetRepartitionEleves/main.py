# ---------- BIBLIOTHEQUES ---------- #

import tkinter as tk
from tkinter import filedialog
import csv
import Eleve
import copy
import os

# ---------- DONNEES ---------- #
cheminFichier = None
nbEleves = 0
nbInterv = 0
nbCreneaux = 0
nbChoixPrimaires = 0
nbChoixSecondaires = 0
nbElevesIntervCreneau = 0

def chercherFichier():
    global cheminFichier
    fichier = filedialog.askopenfilename(title="Choisir le fichier", filetypes=[("Fichiers CSV", "*.csv")])
    if fichier:
        cheminFichier = fichier
        labelFichierCharge.config(text=f"Fichier sélectionné : {fichier}")
    else:
        cheminFichier = None
        labelFichierCharge.config(text="Aucun fichier sélectionné")
    verifierContenus()


def traiterDonnees():
    global nbInterv
    nbInterv = int(entryInterv.get())
    global nbCreneaux
    nbCreneaux = int(entryCreneaux.get())
    global nbChoixPrimaires
    nbChoixPrimaires = int(entryChoixPrimaires.get())
    global nbChoixSecondaires
    nbChoixSecondaires = int(entryChoixSecondaires.get())
    global nbElevesIntervCreneau
    nbElevesIntervCreneau = int(entryElevesIntervCreneau.get())
    fenetreDonnees.destroy()

def verifierContenus(*args):
    global cheminFichier
    if champInterv.get().strip() and champCreneaux.get().strip() and champChoixPrimaires.get().strip() and champChoixSecondaires.get().strip() and champElevesIntervCreneau.get().strip() and cheminFichier != None:
        buttonValidation.config(state="normal")
    else:
        buttonValidation.config(state="disabled")

def exporterSolution():
    chemin = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("Fichier CSV", "*.csv")], title="Enregistrer la solution")
    if chemin:
        with open(chemin, mode="w", newline='', encoding="utf-8") as fichier:
            writer = csv.writer(fichier, delimiter=";")
            writer.writerows(donneesFinales)
        tk.Label(fenetreResultat, text="Merci d'avoir utilisé l'assistant répartiteur !! Vous pouvez dès à présent fermer cette fenêtre et étudier le résultat obtenu.", font=police).pack()

# ---------- INTERFACE GRAPHIQUE 1 ---------- #
fenetreDonnees = tk.Tk()
fenetreDonnees.title("Assistant répartiteur")
fenetreDonnees.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
police = ("Courier Prime", 16, "normal")

labelIntro = tk.Label(fenetreDonnees, text="Bienvenue dans l'Assistant Répartiteur. Veuillez compléter les informations ci-dessous pour lancer l'exécution de la recherche.", font=police)
labelIntro.pack()

labelInterv = tk.Label(fenetreDonnees, text="Saisir le nombre d'intervenants : ", font=police)
labelInterv.pack()
champInterv = tk.StringVar()
champInterv.trace_add("write", verifierContenus)
entryInterv = tk.Entry(fenetreDonnees, font=police, textvariable=champInterv, validate="key", validatecommand=(fenetreDonnees.register(lambda C: C.isdigit() or C == ""), "%P"))
entryInterv.pack()

labelCreneaux = tk.Label(fenetreDonnees, text="Saisir le nombre de créneaux de rencontre : ", font=police)
labelCreneaux.pack()
champCreneaux = tk.StringVar()
champCreneaux.trace_add("write", verifierContenus)
entryCreneaux = tk.Entry(fenetreDonnees, font=police, textvariable=champCreneaux, validate="key", validatecommand=(fenetreDonnees.register(lambda C: C.isdigit() or C == ""), "%P"))
entryCreneaux.pack()

labelChoixPrimaires = tk.Label(fenetreDonnees, text="Saisir le nombre de choix à respecter obligatoirement par élève : ", font=police)
labelChoixPrimaires.pack()
champChoixPrimaires = tk.StringVar()
champChoixPrimaires.trace_add("write", verifierContenus)
entryChoixPrimaires = tk.Entry(fenetreDonnees, font=police, textvariable=champChoixPrimaires, validate="key", validatecommand=(fenetreDonnees.register(lambda C: C.isdigit() or C == ""), "%P"))
entryChoixPrimaires.pack()

labelChoixSecondaires = tk.Label(fenetreDonnees, text="Saisir le nombre de choix à respecter si possible par élève : ", font=police)
labelChoixSecondaires.pack()
champChoixSecondaires = tk.StringVar()
champChoixSecondaires.trace_add("write", verifierContenus)
entryChoixSecondaires = tk.Entry(fenetreDonnees, font=police, textvariable=champChoixSecondaires, validate="key", validatecommand=(fenetreDonnees.register(lambda C: C.isdigit() or C == ""), "%P"))
entryChoixSecondaires.pack()

labelElevesIntervCreneau = tk.Label(fenetreDonnees, text="Saisir le nombre d'élèves que peut voir un intervenant par créneau : ", font=police)
labelElevesIntervCreneau.pack()
champElevesIntervCreneau = tk.StringVar()
champElevesIntervCreneau.trace_add("write", verifierContenus)
entryElevesIntervCreneau = tk.Entry(fenetreDonnees, font=police, textvariable=champElevesIntervCreneau, validate="key", validatecommand=(fenetreDonnees.register(lambda C: C.isdigit() or C == ""), "%P"))
entryElevesIntervCreneau.pack()

buttonChargementFichier = tk.Button(fenetreDonnees, text="Importer le fichier CSV", font=police, command=chercherFichier)
buttonChargementFichier.pack()
labelFichierCharge = tk.Label(fenetreDonnees, text="Aucun fichier sélectionné", font=police)
labelFichierCharge.pack()

buttonValidation = tk.Button(fenetreDonnees, text="Envoyer les données et lancer la recherche", state="disabled", font=police, command=traiterDonnees)
buttonValidation.pack()

fenetreDonnees.mainloop()

Eleve.Eleve.setVariablesClasses(nbInterv, nbCreneaux, nbElevesIntervCreneau)

# ---------- TRAITEMENT FICHIER ---------- #

with open(cheminFichier, newline='', encoding='utf-8') as fichier:
    lecteur = csv.reader(fichier, delimiter=";")
    donneesBrutes = [ligne for ligne in lecteur]

listeEleves = []
for ligne in donneesBrutes[1:]:
    listeEleves.append(Eleve.Eleve(ligne[0], [int(ligne[i]) for i in range(1, nbChoixPrimaires + 1)], [int(ligne[i]) for i in range(nbChoixPrimaires + 1, nbChoixPrimaires + nbChoixSecondaires + 1)]))
    nbEleves += 1

# ---------- ALGORITHME PRINCIPAL ---------- #
## ----- TRI DES ELEVES PAR DIFFICULTE PRIMAIRE ----- ##
Eleve.Eleve.trierListeElevesPrimaire(listeEleves)

## ----- ASSIGNATION DES CHOIX PRIMAIRES ----- ##
for i in range(nbChoixPrimaires):
    for eleve in listeEleves:
        eleve.creerRencontrePrimaire(eleve.getChoixPrimaire(i))

## ----- TRI DES ELEVES PAR DIFFICULTE SECONDAIRE ----- ##
Eleve.Eleve.trierListeElevesSecondaire(listeEleves)

## ----- ASSIGNATION DES CHOIX SECONDAIRES ----- ##
for i in range(nbChoixSecondaires):
    for eleve in listeEleves:
        eleve.creerRencontreSecondaire(eleve.getChoixSecondaire(i))

## ----- REMPLISSAGE DES BLANCS ----- ##
for eleve in listeEleves:
    eleve.remplirTrous()

## ----- PERMUTATIONS ----- ##
def chercherSolution(listeEleves : list, listeModifies : list, numIntervenant : int, numCreneau : int) -> bool:
    for eleve in listeEleves:
        if not(eleve in listeModifies) and eleve.getRencontre(numCreneau) == numIntervenant:
            # On cherche le créneau à permuter
            nouveauxCreneauxPossiblesIntervenant = [] # Forcément non-vide
            for c in range(nbCreneaux):
                if Eleve.Eleve.tableauNombreElevesParIntervenant[numIntervenant][c] < nbElevesIntervCreneau:
                    if (Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(c)][numCreneau] < nbElevesIntervCreneau) or (Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(c)][c] == max(Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(c)]) and Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(c)][numCreneau] < max(Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(c)])):
                        # Super on peut intervertir directement et ce sera bon
                        Eleve.Eleve.tableauNombreElevesParIntervenant[numIntervenant][numCreneau] -= 1
                        Eleve.Eleve.tableauNombreElevesParIntervenant[numIntervenant][c] += 1
                        intervenantDeplace = eleve.getRencontre(c)
                        eleve.setRencontre(c, numIntervenant)
                        Eleve.Eleve.tableauNombreElevesParIntervenant[intervenantDeplace][c] -= 1
                        Eleve.Eleve.tableauNombreElevesParIntervenant[intervenantDeplace][numCreneau] += 1
                        eleve.setRencontre(numCreneau, intervenantDeplace)
                        return True
                    nouveauxCreneauxPossiblesIntervenant.append(c)
            # On permute dans le cas défavorable (on a juste décalé le problème)
            creneauPermutation = nouveauxCreneauxPossiblesIntervenant[0]
            Eleve.Eleve.tableauNombreElevesParIntervenant[numIntervenant][numCreneau] -= 1
            Eleve.Eleve.tableauNombreElevesParIntervenant[numIntervenant][creneauPermutation] += 1
            intervenantDeplace = eleve.getRencontre(creneauPermutation)
            eleve.setRencontre(creneauPermutation, numIntervenant)
            Eleve.Eleve.tableauNombreElevesParIntervenant[intervenantDeplace][creneauPermutation] -= 1
            Eleve.Eleve.tableauNombreElevesParIntervenant[intervenantDeplace][numCreneau] += 1
            eleve.setRencontre(numCreneau, intervenantDeplace)
            listeModifies.append(eleve)
            return chercherSolution(listeEleves, listeModifies, intervenantDeplace, numCreneau)
    return False

Eleve.Eleve.trierListeElevesDefavorise(listeEleves)
sauvegarde = ["listeEleves", "tableauNombreEleveParIntervenant"]
for i in range(len(listeEleves)):
    eleve = listeEleves[i]
    for choixSecondaire in eleve.getListeChoixSecondaires():
        if not(choixSecondaire in eleve.getListeRencontres()) and min([Eleve.Eleve.tableauNombreElevesParIntervenant[choixSecondaire][creneau] for creneau in range(nbCreneaux)]) < nbElevesIntervCreneau:
            sauvegarde = [copy.deepcopy(listeEleves), Eleve.Eleve.tableauNombreElevesParIntervenant]
            listeElevesModifies = []
            indice = eleve.getCreneauTroue()
            Eleve.Eleve.tableauNombreElevesParIntervenant[eleve.getRencontre(indice)][indice] -= 1
            eleve.setRencontre(indice, choixSecondaire)
            Eleve.Eleve.tableauNombreElevesParIntervenant[choixSecondaire][indice] += 1
            listeElevesModifies.append(eleve)
            if Eleve.Eleve.tableauNombreElevesParIntervenant[choixSecondaire][indice] > nbElevesIntervCreneau:
                if not(chercherSolution(listeEleves, listeElevesModifies, choixSecondaire, indice)):
                    listeEleves = sauvegarde[0]
                    Eleve.Eleve.tableauNombreElevesParIntervenant = sauvegarde[1]
                else :
                    sauvegarde = ["listeEleves", "tableauNombreEleveParIntervenant"]


# ---------- RENVOI DES RESULTATS ---------- #
donneesFinales = [["Nom"]]
for i in range(1, nbCreneaux + 1):
    donneesFinales[0].append(f"Créneau {i}")
for eleve in listeEleves:
    donneesFinales.append([eleve.getNom()])
    for i in range(nbCreneaux):
        donneesFinales[-1].append(eleve.getRencontre(i) + 1)

score = 1000 * sum([max(0, Eleve.Eleve.tableauNombreElevesParIntervenant[intervenant][creneau] - nbElevesIntervCreneau) for intervenant in range(nbInterv) for creneau in range(nbCreneaux)])

for eleve in listeEleves:
    for choix in eleve.getListeChoixSecondaires():
        if not(choix in eleve.getListeRencontres()):
            score += 1

fenetreResultat = tk.Tk()
fenetreResultat.title("Succès")

tk.Label(fenetreResultat, font=police, text="Bonne nouvelle, une solution a été trouvé. Elle est évalué à un score de {0}. Comment interpréter ce score ?".format(score)).pack()
tk.Label(fenetreResultat, font=police, text=" - Le nombre de milliers représente le nombre d'élèves que les intervenants ont pu voir en trop.").pack()
tk.Label(fenetreResultat, font=police, text=" - Les trois derniers chiffres représentes le nombre de choix secondaires qui n'ont pas été respectés.").pack()
tk.Label(fenetreResultat, font=police, text="Par exemple, pour le score 2025, il y a eu deux élèves en trop pour des intervenants au total, et 25 choix secondaires n'ont pas été respectés.").pack()
tk.Label(fenetreResultat, font=police, text="En bref, plus le score est faible, mieux c'est !!!")

buttonExportFichier = tk.Button(fenetreResultat, text="Exporter la solution", font=police, command=exporterSolution)
buttonExportFichier.pack()
fenetreResultat.mainloop()