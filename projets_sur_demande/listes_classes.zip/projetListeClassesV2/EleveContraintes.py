texteRemarques = [""]

def ajouterMessageFinal(message):
    texteRemarques[0] += message

# ELEVE
class Eleve:
    nombreClasses = None
    def __init__(self, nom, prenom, options):
        self.nom = nom
        self.prenom = prenom
        self.options = options
        self.classe = None
        self.choix = list(range(1, Eleve.nombreClasses + 1))
        self.contraintesCourantesLiees = []
        self.fixe = False
        self.contrainteNonSatisfaite = False
    def __repr__(self):
        return self.nom + " " + self.prenom
    def supprimerChoix(self, choix, definitif):
        if choix in self.choix:
            self.choix.remove(choix)
            if len(self.choix) == 0:
                ajouterMessageFinal("Pour l'élève {0} {1}, nous avons voulu lui interdire la classe {2}, mais il ne peut pas être positionné ailleurs. Cette contrainte a donc été ignorée pour lui.".format(self.prenom, self.nom, choix))
                self.choix.append(choix)
                self.contrainteNonSatisfaite = True
            elif len(self.choix) == 1:
                self.classe = self.choix[0]
                if definitif:
                    self.fixe = True
            return self.contraintesCourantesLiees
        return []

# CONTRAINTE
class Contrainte:
    def __init__(self):
        self.effectuee = False
    pass

## CONTRAINTES D'OPTION DIRECTEMENT LIEES A UN ELEVE
class ContrainteOption(Contrainte):
    def __init__(self, option, classe):
        super().__init__()
        self.option = option
        self.classe = classe
    def cns(self, listeEleves):
        return 0
class InterdireOptionClasse(ContrainteOption):
    def __init__(self, option, classe):
        super().__init__(option, classe)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            for eleve in listeEleves:
                if self.option in eleve.options:
                    contraintesRefaire += eleve.supprimerChoix(self.classe, definitif)
            self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "InterdireOptionClasse_{0}_{1}".format(self.option, self.classe)
class ForcerOptionClasse(ContrainteOption):
    def __init__(self, option, classe):
        super().__init__(option, classe)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            for eleve in listeEleves:
                if self.option in eleve.options:
                    for classe in range(1, Eleve.nombreClasses + 1):
                        if classe != self.classe:
                            contraintesRefaire += eleve.supprimerChoix(classe, definitif)
            self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "ForcerOptionClasse_{0}_{1}".format(self.option, self.classe)

## CONTRAINTES D'OPTION DIRECTEMENT LIEES A UN ELEVE
class ContrainteEleve(Contrainte):
    def __init__(self, eleve, classe):
        super().__init__()
        self.eleve = eleve
        self.classe = classe
    def cns(self, listeEleves):
        return 0
class InterdireEleveClasse(ContrainteEleve):
    def __init__(self, eleve, classe):
        super().__init__(eleve, classe)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            contraintesRefaire += self.eleve.supprimerChoix(self.classe, definitif)
            self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "InterdireEleveClasse_{0}_{1}_{2}".format(self.eleve.nom, self.eleve.prenom, self.classe)
class ForcerEleveClasse(ContrainteEleve):
    def __init__(self, eleve, classe):
        super().__init__(eleve, classe)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            for classe in range(1, Eleve.nombreClasses + 1):
                if classe != self.classe:
                    contraintesRefaire += self.eleve.supprimerChoix(classe, definitif)
            self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "ForcerEleveClasse_{0}_{1}_{2}".format(self.eleve.nom, self.eleve.prenom, self.classe)

## CONTRAINTES DE CLASSES LIEES A L'ENSEMBLE DES ELEVES
class ContrainteClasse(Contrainte):
    def __init__(self, classe, nombre, operateur):
        super().__init__()
        self.classe = classe
        self.nombre = nombre
        self.operateur = operateur
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            concernesPlaces = []
            concernesNonPlaces = []
            nonConcernes = []
            for eleve in listeEleves:
                if self.optionEleve(eleve):
                    if eleve.classe == self.classe:
                        concernesPlaces.append(eleve)
                    elif eleve.classe == None and self.classe in eleve.choix:
                        concernesNonPlaces.append(eleve)
                    else:
                        nonConcernes.append(eleve)
            if len(concernesPlaces) + len(concernesNonPlaces) < self.nombre and self.operateur == "<": #VALIDE
                self.effectuee = True
                return []
            if len(concernesPlaces) >= self.nombre and self.operateur == "<": # TROP
                self.messageTrop(len(concernesPlaces)-self.nombre+1)
                for eleve in concernesNonPlaces:
                    contraintesRefaire += eleve.supprimerChoix(self.classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) == self.nombre - 1 and self.operateur == "<": #VALIDE
                for eleve in concernesNonPlaces:
                    contraintesRefaire += eleve.supprimerChoix(self.classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) + len(concernesNonPlaces) == self.nombre and self.operateur == "=": #VALIDE
                for eleve in concernesNonPlaces:
                    for classe in range(1, Eleve.nombreClasses + 1):
                        if classe != self.classe:
                            contraintesRefaire += eleve.supprimerChoix(classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) + len(concernesNonPlaces) < self.nombre and self.operateur == "=": # PAS ASSEZ
                self.messageManque(self.nombre-len(concernesNonPlaces)-len(concernesPlaces))    
                for eleve in concernesNonPlaces:
                    for classe in range(1, Eleve.nombreClasses + 1):
                        if classe != self.classe:
                            contraintesRefaire += eleve.supprimerChoix(classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) == self.nombre and self.operateur == "=": #VALIDE
                for eleve in concernesNonPlaces:
                    contraintesRefaire += eleve.supprimerChoix(self.classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) > self.nombre and self.operateur == "=": #TROP
                self.messageTrop(len(concernesPlaces)-self.nombre+1)
                for eleve in concernesNonPlaces:
                    contraintesRefaire += eleve.supprimerChoix(self.classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) + len(concernesNonPlaces) <= self.nombre and self.operateur == ">": #PAS ASSEZ
                self.messageManque(self.nombre-len(concernesNonPlaces)-len(concernesPlaces)+1)
                for eleve in concernesNonPlaces:
                    for classe in range(1, Eleve.nombreClasses + 1):
                        if classe != self.classe:
                            contraintesRefaire += eleve.supprimerChoix(classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            if len(concernesPlaces) > self.nombre and self.operateur == ">": #VALIDE
                self.effectuee = True
                return []
            if len(concernesPlaces) + len(concernesNonPlaces) == self.nombre + 1 and self.operateur == ">": #VALIDE
                for eleve in concernesNonPlaces:
                    for classe in range(1, Eleve.nombreClasses + 1):
                        if classe != self.classe:
                            contraintesRefaire += eleve.supprimerChoix(classe, definitif)
                self.effectuee = True
                return contraintesRefaire
            return []
        else:
            return []
    def cns(self, listeEleves):
        comptePlace, compteNonPlace = 0, 0
        for eleve in listeEleves:
            if self.optionEleve(eleve):
                if eleve.classe == self.classe:
                    comptePlace += 1
                elif self.classe in eleve.choix:
                    compteNonPlace += 1
        if self.operateur == "<":
            return max(comptePlace - self.nombre + 1, 0)
        if self.operateur == "=":
            return max(comptePlace - self.nombre, 0, self.nombre - comptePlace - compteNonPlace)
        if self.operateur == ">":
            return max(self.nombre - comptePlace - compteNonPlace + 1, 0)
class NombreElevesOptionClasse(ContrainteClasse):
    def __init__(self, classe, nombre, operateur, option, listeEleves):
        super().__init__(classe, nombre, operateur)
        self.option = option
        for eleve in listeEleves:
            if self.optionEleve(eleve):
                eleve.contraintesCourantesLiees.append(self)
    def optionEleve(self, eleve):
        return self.option in eleve.options
    def messageManque(self, nombre):
        ajouterMessageFinal("Il manque {0} élèves pour suivre l'option {1} dans la classe {2}.".format(nombre, self.option, self.classe))
    def messageTrop(self, nombre):
        ajouterMessageFinal("Il y a {0} élèves en trop qui suivent l'option {1} dans la classe {2}.".format(nombre, self.option, self.classe))
    def export(self):
        return "NombreElevesOptionClasse_{0}_{1}_{2}_{3}".format(self.classe, self.nombre, self.operateur, self.option)
class NombreElevesClasse(ContrainteClasse):
    def __init__(self, classe, nombre, operateur, listeEleves):
        super().__init__(classe, nombre, operateur)
        for eleve in listeEleves:
            eleve.contraintesCourantesLiees.append(self)
    def optionEleve(self, eleve : Eleve):
        return True
    def messageManque(self, nombre):
        ajouterMessageFinal("Il manque {0} élèves dans la classe {1}.".format(nombre, self.classe))
    def messageTrop(self, nombre):
        ajouterMessageFinal("Il y a {0} élèves en trop dans la classe {1}.".format(nombre, self.classe))
    def export(self):
        return "NombreElevesClasse_{0}_{1}_{2}".format(self.classe, self.nombre, self.operateur)

## CONTRAINTES D'ELEVES
class ContrainteEleves(Contrainte):
    def __init__(self, eleve1, eleve2):
        super().__init__()
        self.eleve1 = eleve1
        self.eleve2 = eleve2
        eleve1.contraintesCourantesLiees.append(self)
        eleve2.contraintesCourantesLiees.append(self)
    def cns(self, listeEleves):
        return 0
class SeparerEleves(ContrainteEleves):
    def __init__(self, eleve1, eleve2):
        super().__init__(eleve1, eleve2)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            if self.eleve1.classe != None:
                contraintesRefaire += self.eleve2.supprimerChoix(self.eleve1.classe, definitif)
                self.effectuee = True
            if self.eleve2.classe != None:
                contraintesRefaire += self.eleve1.supprimerChoix(self.eleve2.classe, definitif)
                self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "SeparerEleves_{0}_{1}_{2}_{3}".format(self.eleve1.nom, self.eleve1.prenom, self.eleve2.nom, self.eleve2.prenom)
class RegrouperEleves(ContrainteEleves):
    def __init__(self, eleve1, eleve2):
        super().__init__(eleve1, eleve2)
    def appliquer(self, listeEleves, definitif):
        if not self.effectuee:
            contraintesRefaire = []
            for classe in self.eleve1.choix:
                if not classe in self.eleve2.choix:
                    contraintesRefaire += self.eleve1.supprimerChoix(classe, definitif)
            for classe in self.eleve2.choix:
                if not classe in self.eleve1.choix:
                    contraintesRefaire += self.eleve2.supprimerChoix(classe, definitif)
            if len(self.eleve1.choix) == 1:
                self.effectuee = True
            return contraintesRefaire
        return []
    def export(self):
        return "RegrouperEleves_{0}_{1}_{2}_{3}".format(self.eleve1.nom, self.eleve1.prenom, self.eleve2.nom, self.eleve2.prenom)

# EQUILIBRE
class Equilibre:
    def __init__(self, listeOptions, listeClasses):
        self.options = listeOptions
        self.classes = listeClasses
class EquilibreOptionClasses(Equilibre):
    def __init__(self, listeOptions, listeClasses):
        super().__init__(listeOptions, listeClasses)
    def calculerScore(self, listeEleves):
        resultat = [0 for i in range(len(self.classes))]
        for eleve in listeEleves:
            if eleve.classe in self.classes:
                if [opt for opt in eleve.options if opt in self.options]:
                    resultat[self.classes.index(eleve.classe)] += 1
        for eleve in listeEleves:
            if eleve.classe == None and [opt for opt in eleve.options if opt in self.options]:
                resultat[min([i for i in range(len(self.classes)) if self.classes[i] in eleve.choix], key=(lambda i: resultat[i]))] += 1
        score = 0
        for n1 in resultat:
            for n2 in resultat:
                score += abs(n2-n1)
        return score//2
    def export(self):
        txtOptions = ""
        for o in self.options:
            txtOptions += o + ";"
        txtClasses = ""
        for c in self.classes:
            txtClasses += str(c) + ";"
        return "EquilibreOptionClasses_{0}_{1}".format(txtOptions[:-1], txtClasses[:-1])
class EquilibreOptionsClasse(Equilibre):
    def __init__(self, listeOptions, listeClasses):
        super().__init__(listeOptions, listeClasses)
    def calculerScore(self, listeEleves):
        resultat = [0 for i in range(len(self.options))]
        for eleve in listeEleves:
            if [c for c in eleve.choix if c in self.classes] != []:
                for opt in [opt for opt in eleve.options if opt in self.options]:
                    resultat[self.options.index(opt)] += 1
        score = 0
        for n1 in resultat:
            for n2 in resultat:
                score += abs(n2-n1)
        return score//2
    def export(self):
        txtOptions = ""
        for o in self.options:
            txtOptions += o + ";"
        txtClasses = ""
        for c in self.classes:
            txtClasses += str(c) + ";"
        return "EquilibreOptionsClasse_{0}_{1}".format(txtOptions[:-1], txtClasses[:-1])

def afficherStats(listeEleves, listeContraintes):
    nf, n1, n2, n3, inc = 0, 0, 0, 0, 0
    for eleve in listeEleves:
        if eleve.classe == None:
            nf += 1
        elif eleve.classe == 1:
            n1 += 1
        elif eleve.classe == 2:
            n2 += 1
        elif eleve.classe == 3:
            n3 += 1
        else:
            inc += 1
    f, a = 0, 0
    for contrainte in listeContraintes:
        if contrainte.effectuee:
            f += 1
        else:
            a += 1
    print("/* STATISTIQUES SUR LES ELEVES */")
    print(" * Nombre d'élèves non fixés : {0}".format(nf))
    print(" * Nombre d'élèves fixés en classe 1 : {0}".format(n1))
    print(" * Nombre d'élèves fixés en classe 2 : {0}".format(n2))
    print(" * Nombre d'élèves fixés en classe 3 : {0}".format(n3))
    print(" * Nombre d'élèves perdus dans la campagne : {0}".format(inc))
    print("/* STATISTIQUES SUR LES CONTRAINTES */")
    print(" * Nombre de contraintes terminées : {0}".format(f))
    print(" * Nombre de contraintes pas finies : {0}".format(a))