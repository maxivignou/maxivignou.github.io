import EleveContraintes
import csv
import tkinter
import os
from functools import cmp_to_key
from tkinter import ttk
from tkinter import filedialog
import copy
import threading
police_standard = ("Courier Prime", 16, "normal")
police_titre = ("Courier Prime", 20, "bold")
police_raye = ("Courier Prime", 16, "overstrike")

def interfaceInitiale():
    global_datas = [None, 0]
    
    def chercherFichier():
        fichier = tkinter.filedialog.askopenfilename(title="Choisir le fichier", filetypes=[("Fichiers CSV", "*.csv")])
        if fichier:
            global_datas[0] = fichier
            stringvarFichierEleves.set("Fichier sélectionné : {0}".format(fichier))
        else:
            global_datas[0] = None
            stringvarFichierEleves.set("Aucun fichier sélectionné")
        verifierChamps()
    
    def verifierChamps(event=None):
        if global_datas[0] != None and entryNombreClasses.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    
    def envoiDonnees():
        global_datas[1] = int(entryNombreClasses.get())
        interface.destroy()
    
    interface = tkinter.Tk()
    interface.title("Assistant Listes de classes")
    interface.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
    interface.geometry("{0}x{1}".format(interface.winfo_screenwidth(), interface.winfo_screenheight()-100))
    tkinter.Label(interface, text="Bienvenue dans l'Assistant Listes de classes. Veuillez compléter les informations ci-dessous pour lancer l'exécution de la recherche.", font=police_standard).pack()
    tkinter.Label(interface, text="", font=police_standard).pack()
    
    tkinter.Button(interface, text="Fichier CSV des élèves", font=police_titre, command=chercherFichier).pack()
    stringvarFichierEleves = tkinter.StringVar()
    stringvarFichierEleves.set("Aucun fichier sélectionné")
    tkinter.Label(interface, textvariable=stringvarFichierEleves, font=police_standard).pack()
    tkinter.Label(interface, text="Remarque : Pour une meilleure répartition des élèves, il faut mélanger les élèves dans le fichier CSV.", font=police_standard).pack()
    tkinter.Label(interface, text="Il faut créer une colonne provisoire avec un nombre aléatoire (ALEA.ENTRE.BORNES), trier par cette colonne, puis supprimer la colonne.", font=police_standard).pack()
    tkinter.Label(interface, text="", font=police_standard).pack()
    
    tkinter.Label(interface, text="Nombre de classes", font=police_titre).pack()
    entryNombreClasses = tkinter.Entry(interface, width=5, font=police_standard, validate="key")
    entryNombreClasses['validatecommand'] = (interface.register(lambda v: v.isdigit() or v == ""), "%P")
    entryNombreClasses.pack()
    entryNombreClasses.bind("<KeyRelease>", verifierChamps)
    tkinter.Label(interface, text="", font=police_standard).pack()
    
    buttonValidation = tkinter.Button(interface, text="Valider", command=envoiDonnees, font=police_titre, state="disabled")
    buttonValidation.pack()
    tkinter.Label(interface, text="", font=police_standard).pack()
    
    interface.mainloop()
    
    EleveContraintes.Eleve.nombreClasses = global_datas[1]
    listeEleves = []
    with open(global_datas[0], encoding="utf-8-sig") as fichierEleves:
        listeOptions = [""]
        lecteur = csv.reader(fichierEleves, delimiter=";")
        next(lecteur)
        for ligne in lecteur:
            listeEleves.append(EleveContraintes.Eleve(ligne[0], ligne[1], ligne[2:])) # Le CSV doit être NOM;PRENOM;NIVEAU;OPTIONS
            for option in ligne[2:]:
                if not option in listeOptions:
                    listeOptions.append(option)
        listeOptions.sort()
        return listeEleves, listeOptions

def interfaceResultat():
    def terminer():
        continuerRecherche[0] = False
        buttonStop.config(text="La recherche a déjà été stoppée.")
        buttonStop.config(state="disabled")
    def telecharger():
        chemin = tkinter.filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("Fichiers CSV", "*.csv"), ("Tous les fichiers", "*.*")], title="Enregistrer le résultat")
        if chemin:
            buttonTelechargement.config(text="Vous avez déjà téléchargé le fichier, mais vous pouvez recommencer.")
            with open(chemin, "w") as fichier:
                maxOptions = max([len(eleve.options) for eleve in resultat[0]])
                fichier.write("Nom;Prenom;")
                for i in range(maxOptions):
                    fichier.write("Option {0};".format(i+1))
                fichier.write("Classe;Fixe?;Contraintes Satisfaites ?\n")
                for eleve in resultat[0]:
                    fichier.write("{0};{1};".format(eleve.nom, eleve.prenom))
                    for i in range(maxOptions):
                        if i < len(eleve.options):
                            fichier.write(eleve.options[i])
                        fichier.write(";")
                    fichier.write("{0};{1};{2}\n".format(chr(64+eleve.classe), "OUI" if eleve.fixe else "NON", "NON" if eleve.contrainteNonSatisfaite else "OUI"))
    def exporter():
        chemin = tkinter.filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Fichiers TXT", "*.txt"), ("Tous les fichiers", "*.*")], title="Exporter les contraintes")
        if chemin:
            buttonContraintes.config(text="Vous avez déjà sauvegardé les fonctraintes, mais vous pouvez recommencer.")
            with open(chemin, "w") as fichier:
                for c in listeContraintes:
                    fichier.write("{0}\n".format(c.export()))
                for e in listeEquilibres:
                    fichier.write("{0}\n".format(e.export()))
    def mettreAJour():
        if resultat[0] is None:
            labelCNS.config(text="Recherche en cours...")
            labelScore.config(text="")
            buttonTelechargement.config(state="disabled")
        else:
            labelCNS.config(text="Actuellement, {0} élèves ne respectent pas les contraintes fournies.".format(resultat[1]))
            labelScore.config(text="Le score d'équilibre est le suivant : {0} points.".format(resultat[2]))
            buttonTelechargement.config(state="normal")
        interface.after(500, mettreAJour)
    interface = tkinter.Tk()
    interface.title("Assistant Listes de classes")
    interface.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
    interface.geometry("{0}x{1}".format(interface.winfo_screenwidth(), interface.winfo_screenheight()-100))
    tkinter.Label(interface, text="Je suis en train de chercher, voici l'évolution de ma recherche : ", font=police_standard).pack()
    tkinter.Label(interface, text="", font=police_standard).pack()
    labelCNS = tkinter.Label(interface, text="Recherche en cours...", font=police_standard)
    labelCNS.pack()
    labelScore = tkinter.Label(interface, text="", font=police_standard)
    labelScore.pack()
    tkinter.Label(interface, text="", font=police_standard).pack()
    buttonTelechargement = tkinter.Button(interface, text="Télécharger le meilleur résultat", command=telecharger, font=police_titre, state="disabled")
    buttonTelechargement.pack()
    buttonContraintes = tkinter.Button(interface, text="Sauvegarder les contraintes et les équilibres", command=exporter, font=police_titre)
    buttonContraintes.pack()
    buttonStop = tkinter.Button(interface, text="Stopper la recherche, ces statistiques me conviennent", command=terminer, font=police_titre)
    buttonStop.pack()
    mettreAJour()
    interface.mainloop()

def interfaceContraintes():
    interface = tkinter.Tk()
    interface.title("Assistant Listes de classes")
    interface.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
    interface.geometry("{0}x{1}".format(interface.winfo_screenwidth(), interface.winfo_screenheight()-100))
    canvas = tkinter.Canvas(interface)
    scrollbar = tkinter.Scrollbar(interface, orient="vertical", command=canvas.yview)
    scrollbar.pack(side="right", fill="y")
    frame = tkinter.Frame(canvas)
    frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(-1 * int(e.delta / 120), "units"))
    canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas.create_window((0, 0), window=frame, anchor="nw"), width=e.width))
    canvas.pack(side="left", fill="both", expand=True)
    
    textContraintesAjoutees = tkinter.Frame(frame)
    tkinter.Label(textContraintesAjoutees, text="Recapitulatif des contraintes", font=police_titre).pack()
    
    tkinter.Label(frame, text="A présent, vous pouvez ajouter des contraintes sur la répartition des élèves.", font=police_standard).grid(row=0, column=0, columnspan=2)
    tkinter.Label(frame, text="En cas d'insatisfiabilité, les contraintes sont appliquées par ordre d'arrivée. Veuillez donc entrer d'abord les contraintes les plus importantes.", font=police_standard).grid(row=1, column=0, columnspan=2)
    tkinter.Label(frame, text="", font=police_standard).grid(row=2, column=0, columnspan=2)
    
    interfaceChargerContraintes(frame, textContraintesAjoutees)
    
    interfaceInterdireOptionClasse(frame, textContraintesAjoutees)
    interfaceForcerOptionClasse(frame, textContraintesAjoutees)
    interfaceNombreElevesOptionClasse(frame, textContraintesAjoutees)
    interfaceNombreElevesClasse(frame, textContraintesAjoutees)
    interfaceSeparerEleves(frame, textContraintesAjoutees)
    interfaceRegrouperEleves(frame, textContraintesAjoutees)
    interfaceInterdireEleveClasse(frame, textContraintesAjoutees)
    interfaceForcerEleveClasse(frame, textContraintesAjoutees)
    
    interfaceEquilibreOptionClasses(frame, textContraintesAjoutees)
    interfaceEquilibreOptionsClasse(frame, textContraintesAjoutees)
    
    textContraintesAjoutees.grid(row=10, column=0, columnspan=2)
    tkinter.Label(frame, text="", font=police_standard).grid(row=11, column=0, columnspan=2)
    tkinter.Button(frame, text="Valider les contraintes et l'équilibrage, chercher une solution optimale", command=(lambda event=None: interface.destroy()), font=police_standard).grid(row=12, column=0, columnspan=2)
    tkinter.Label(frame, text="", font=police_standard).grid(row=13, column=0, columnspan=2)
    
    interface.mainloop()

def ajouterBilan(textContraintes, label, contrainte, listeContraintes):
    def supprimer():
        listeContraintes.remove(contrainte)
        labelSuppr.config(font=police_raye)
        buttonSuppr.config(state="disabled")
        buttonSuppr.config(text="Contrainte supprimée")
    ligne = tkinter.Frame(textContraintes)
    labelSuppr = tkinter.Label(ligne, text=label, font=police_standard)
    labelSuppr.grid(row=0, column=0, padx=10)
    buttonSuppr = tkinter.Button(ligne, text="Supprimer la contrainte", command=supprimer, font=police_standard)
    buttonSuppr.grid(row=0, column=1)
    ligne.pack()

def interfaceChargerContraintes(frame, textContraintes):
    def chercherFichier():
        fichier = tkinter.filedialog.askopenfilename(title="Choisir le fichier", filetypes=[("Fichiers TXT", "*.txt")])
        if fichier:
            nom_fichier[0] = fichier
            stringvarFichierContraintes.set("Fichier sélectionné : {0}".format(fichier))
        else:
            nom_fichier[0] = None
            stringvarFichierContraintes.set("Aucun fichier sélectionné")
        verifierChamps()
    def verifierChamps(event=None):
        if nom_fichier[0]:
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        with open(nom_fichier[0], encoding="utf-8-sig") as fichierContraintes:
            lecteur = csv.reader(fichierContraintes, delimiter="_")
            for ligne in lecteur:
                if ligne[0] == "InterdireOptionClasse":
                    listeContraintes.append(EleveContraintes.InterdireOptionClasse(ligne[1], int(ligne[2])))
                    ajouterBilan(textContraintes, "Option {0} interdite dans la classe {1}".format(ligne[1], chr(64+int(ligne[2]))), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "ForcerOptionClasse":
                    listeContraintes.append(EleveContraintes.ForcerOptionClasse(ligne[1], int(ligne[2])))
                    ajouterBilan(textContraintes, "Option {0} forcée dans la classe {1}".format(ligne[1], chr(64+int(ligne[2]))), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "NombreElevesOptionClasse":
                    listeContraintes.append(EleveContraintes.NombreElevesOptionClasse(int(ligne[1]), int(ligne[2]), ligne[3], ligne[4], listeEleves))
                    ajouterBilan(textContraintes, "Nombre d'élèves suivant l'option {0} dans la classe {1} {2} {3}".format(ligne[4], chr(64+int(ligne[1])), ligne[3], ligne[2]), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "NombreElevesClasse":
                    listeContraintes.append(EleveContraintes.NombreElevesClasse(int(ligne[1]), int(ligne[2]), ligne[3], listeEleves))
                    ajouterBilan(textContraintes, "Nombre d'élèves dans la classe {0} {1} {2}".format(chr(64+int(ligne[1])), ligne[3], ligne[2]), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "SeparerEleves":
                    listeContraintes.append(EleveContraintes.SeparerEleves([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], [eleve for eleve in listeEleves if eleve.nom == ligne[3] and eleve.prenom == ligne[4]][0]))
                    ajouterBilan(textContraintes, "Séparation de {0} et {1}".format([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], [eleve for eleve in listeEleves if eleve.nom == ligne[3] and eleve.prenom == ligne[4]][0]), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "RegrouperEleves":
                    listeContraintes.append(EleveContraintes.RegrouperEleves([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], [eleve for eleve in listeEleves if eleve.nom == ligne[3] and eleve.prenom == ligne[4]][0]))
                    ajouterBilan(textContraintes, "Regroupement de {0} et {1}".format([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], [eleve for eleve in listeEleves if eleve.nom == ligne[3] and eleve.prenom == ligne[4]][0]), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "InterdireEleveClasse":
                    listeContraintes.append(EleveContraintes.InterdireEleveClasse([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], int(ligne[3])))
                    ajouterBilan(textContraintes, "{0} interdit dans la classe {1}".format([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], chr(64+int(ligne[3]))), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "ForcerEleveClasse":
                    listeContraintes.append(EleveContraintes.ForcerEleveClasse([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], int(ligne[3])))
                    ajouterBilan(textContraintes, "{0} forcé dans la classe {1}".format([eleve for eleve in listeEleves if eleve.nom == ligne[1] and eleve.prenom == ligne[2]][0], chr(64+int(ligne[3]))), listeContraintes[-1], listeContraintes)
                elif ligne[0] == "EquilibreOptionClasses":
                    listeEquilibres.append(EleveContraintes.EquilibreOptionClasses(ligne[1].split(";"), [int(c) for c in ligne[2].split(";")]))
                    ajouterBilan(textContraintes, "Equilibrage des élèves suivant des options parmi {0} entre les classes {1}".format(ligne[1].split(";"), [chr(64+int(c)) for c in ligne[2].split(";")]), listeEquilibres[-1], listeEquilibres)
                elif ligne[0] == "EquilibreOptionsClasse":
                    listeEquilibres.append(EleveContraintes.EquilibreOptionsClasse(ligne[1].split(";"), [int(c) for c in ligne[2].split(";")]))
                    ajouterBilan(textContraintes, "Equilibrage des options {0} à l'intérieur des classes {1}".format(ligne[1].split(";"), [chr(64+int(c)) for c in ligne[2].split(";")]), listeEquilibres[-1], listeEquilibres)
                else:
                    print("Contrainte inconnue")
        nom_fichier[0] = None
        stringvarFichierContraintes.set("Aucun fichier sélectionné")
        verifierChamps()
    nom_fichier = [None]
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Charger des contraintes", font=police_titre).pack()
    tkinter.Button(sousframe, text="Fichier TXT des contraintes", font=police_standard, command=chercherFichier).pack()
    stringvarFichierContraintes = tkinter.StringVar()
    stringvarFichierContraintes.set("Aucun fichier sélectionné")
    tkinter.Label(sousframe, textvariable=stringvarFichierContraintes, font=police_standard).pack()
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.pack()
    tkinter.Label(sousframe, text="", font=police_standard).pack()
    sousframe.grid(row=3, column=0, columnspan=2)

def interfaceInterdireOptionClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if comboOption.get().strip() and entryClasse.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.InterdireOptionClasse(comboOption.get(), ord(entryClasse.get())-64))
        ajouterBilan(textContraintes, "Option {0} interdite dans la classe {1}".format(comboOption.get(), entryClasse.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        comboOption.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Interdire une option dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Option concernée", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboOption = tkinter.ttk.Combobox(sousframe, width=10, values=listeOptions, state="readonly", font=police_standard)
    comboOption.grid(row=1, column=1, sticky="w", padx=10)
    comboOption.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=2, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=4, column=0, padx=10)

def interfaceForcerOptionClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if comboOption.get().strip() and entryClasse.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.ForcerOptionClasse(comboOption.get(), ord(entryClasse.get())-64))
        ajouterBilan(textContraintes, "Option {0} forcée dans la classe {1}".format(comboOption.get(), entryClasse.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        comboOption.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Forcer une option dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Option concernée", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboOption = tkinter.ttk.Combobox(sousframe, width=10, values=listeOptions, state="readonly", font=police_standard)
    comboOption.grid(row=1, column=1, sticky="w", padx=10)
    comboOption.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=2, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=4, column=1, padx=10)

def interfaceNombreElevesOptionClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if comboOption.get().strip() and entryClasse.get().strip() and comboOperateur.get().strip() and entryNombre.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.NombreElevesOptionClasse(ord(entryClasse.get())-64, int(entryNombre.get()), comboOperateur.get(), comboOption.get(), listeEleves))
        ajouterBilan(textContraintes, "Nombre d'élèves suivant l'option {0} dans la classe {1} {2} {3}".format(comboOption.get(), entryClasse.get(), comboOperateur.get(), entryNombre.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        comboOption.current(0)
        entryNombre.delete(0, tkinter.END)
        comboOperateur.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Nombre d'élèves suivant une option dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Option concernée", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboOption = tkinter.ttk.Combobox(sousframe, width=10, values=listeOptions, state="readonly", font=police_standard)
    comboOption.grid(row=1, column=1, sticky="w", padx=10)
    comboOption.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=2, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    tkinter.Label(sousframe, text="Nombre d'élèves suivant l'option", font=police_standard).grid(row=3, column=0, sticky="e", padx=10)
    sousousframe = tkinter.Frame(sousframe)
    sousousframe.grid(row=3, column=1, sticky="w", padx=5)
    comboOperateur = tkinter.ttk.Combobox(sousousframe, width=5, values=["", "<", "=", ">"], state="readonly", font=police_standard)
    comboOperateur.pack(side="left", padx=5)
    comboOperateur.bind("<<ComboboxSelected>>", verifierChamps)
    entryNombre = tkinter.Entry(sousousframe, width=5, font=police_standard, validate="key")
    entryNombre['validatecommand'] = (frame.register(lambda v: v.isdigit() or v == ""), "%P")
    entryNombre.pack(side="left", padx=5)
    entryNombre.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=4, column=0, columnspan=3)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=5, column=0, columnspan=3)
    sousframe.grid(row=5, column=0, padx=10)

def interfaceNombreElevesClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if entryClasse.get().strip() and comboOperateur.get().strip() and entryNombre.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.NombreElevesClasse(ord(entryClasse.get())-64, int(entryNombre.get()), comboOperateur.get(), listeEleves))
        ajouterBilan(textContraintes, "Nombre d'élèves dans la classe {0} {1} {2}".format(entryClasse.get(), comboOperateur.get(), entryNombre.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        entryNombre.delete(0, tkinter.END)
        comboOperateur.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Nombre d'élèves dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=1, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    tkinter.Label(sousframe, text="Nombre d'élèves", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    sousousframe = tkinter.Frame(sousframe)
    sousousframe.grid(row=2, column=1, sticky="w", padx=5)
    comboOperateur = tkinter.ttk.Combobox(sousousframe, width=5, values=["", "<", "=", ">"], state="readonly", font=police_standard)
    comboOperateur.pack(side="left", padx=5)
    comboOperateur.bind("<<ComboboxSelected>>", verifierChamps)
    entryNombre = tkinter.Entry(sousousframe, width=5, font=police_standard, validate="key")
    entryNombre['validatecommand'] = (frame.register(lambda v: v.isdigit() or v == ""), "%P")
    entryNombre.pack(side="left", padx=5)
    entryNombre.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=5, column=1, padx=10)

def interfaceSeparerEleves(frame, textContraintes):
    def verifierChamps(event=None):
        if comboEleve1.get() and comboEleve2.get() and comboEleve1.get() != comboEleve2.get():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.SeparerEleves([eleve for eleve in listeEleves if eleve.__repr__() == comboEleve1.get()][0], [eleve for eleve in listeEleves if eleve.__repr__() == comboEleve2.get()][0]))
        ajouterBilan(textContraintes, "Séparation de {0} et {1}".format(comboEleve1.get(), comboEleve2.get()), listeContraintes[-1], listeContraintes)
        comboEleve1.current(0)
        comboEleve2.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Séparer deux élèves", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Eleve", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboEleve1 = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve1.grid(row=1, column=1, sticky="w", padx=10)
    comboEleve1.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Eleve", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    comboEleve2 = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve2.grid(row=2, column=1, sticky="w", padx=10)
    comboEleve2.bind("<<ComboboxSelected>>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=6, column=0, padx=10)

def interfaceRegrouperEleves(frame, textContraintes):
    def verifierChamps(event=None):
        if comboEleve1.get() and comboEleve2.get() and comboEleve1.get() != comboEleve2.get():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.RegrouperEleves([eleve for eleve in listeEleves if eleve.__repr__() == comboEleve1.get()][0], [eleve for eleve in listeEleves if eleve.__repr__() == comboEleve2.get()][0]))
        ajouterBilan(textContraintes, "Regroupement de {0} et {1}".format(comboEleve1.get(), comboEleve2.get()), listeContraintes[-1], listeContraintes)
        comboEleve1.current(0)
        comboEleve2.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Regrouper deux élèves", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Eleve", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboEleve1 = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve1.grid(row=1, column=1, sticky="w", padx=10)
    comboEleve1.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Eleve", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    comboEleve2 = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve2.grid(row=2, column=1, sticky="w", padx=10)
    comboEleve2.bind("<<ComboboxSelected>>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=6, column=1, padx=10)


def interfaceInterdireEleveClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if comboEleve.get().strip() and entryClasse.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.InterdireEleveClasse([eleve for eleve in listeEleves if eleve.__repr__() == comboEleve.get()][0], ord(entryClasse.get())-64))
        ajouterBilan(textContraintes, "{0} interdit dans la classe {1}".format(comboEleve.get(), entryClasse.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        comboEleve.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Interdire un élève dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Elève concerné", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboEleve = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve.grid(row=1, column=1, sticky="w", padx=10)
    comboEleve.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=2, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=7, column=0, padx=10)


def interfaceForcerEleveClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if comboEleve.get().strip() and entryClasse.get().strip():
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeContraintes.append(EleveContraintes.ForcerEleveClasse([eleve for eleve in listeEleves if eleve.__repr__() == comboEleve.get()][0], ord(entryClasse.get())-64))
        ajouterBilan(textContraintes, "{0} forcé dans la classe {1}".format(comboEleve.get(), entryClasse.get()), listeContraintes[-1], listeContraintes)
        entryClasse.delete(0, tkinter.END)
        comboEleve.current(0)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Forcer un élève dans une classe", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Elève concerné", font=police_standard).grid(row=1, column=0, sticky="e", padx=10)
    comboEleve = tkinter.ttk.Combobox(sousframe, width=10, values=[""]+listeEleves, state="readonly", font=police_standard)
    comboEleve.grid(row=1, column=1, sticky="w", padx=10)
    comboEleve.bind("<<ComboboxSelected>>", verifierChamps)
    tkinter.Label(sousframe, text="Classe concernée", font=police_standard).grid(row=2, column=0, sticky="e", padx=10)
    entryClasse = tkinter.Entry(sousframe, width=5, font=police_standard, validate="key")
    entryClasse['validatecommand'] = (frame.register(lambda v: len(v) == 1 or v == ""), "%P")
    entryClasse.grid(row=2, column=1, sticky="w", padx=10)
    entryClasse.bind("<KeyRelease>", verifierChamps)
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=7, column=1, padx=10)


def interfaceEquilibreOptionClasses(frame, textContraintes):
    def verifierChamps(event=None):
        if len([option for option, variable in variablesOptions.items() if variable.get()]) != 0 and len([classe for classe, variable in variablesClasses.items() if variable.get()]) != 0:
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeEquilibres.append(EleveContraintes.EquilibreOptionClasses([option for option, variable in variablesOptions.items() if variable.get()], [ord(classe)-64 for classe, variable in variablesClasses.items() if variable.get()]))
        ajouterBilan(textContraintes, "Equilibrage des élèves suivant des options parmi {0} entre les classes {1}".format([option for option, variable in variablesOptions.items() if variable.get()], [classe for classe, variable in variablesClasses.items() if variable.get()]), listeEquilibres[-1], listeEquilibres)
        for option, variable in variablesOptions.items():
            variable.set(False)
        for classe, variable in variablesClasses.items():
            variable.set(False)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Equilibrer la répartition des élèves suivant une option entre les classes", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Options concernées", font=police_standard).grid(row=1, column=0)
    sousousframeOptions = tkinter.Frame(sousframe)
    sousousframeOptions.grid(row=2, column=0)
    variablesOptions = {option: tkinter.BooleanVar() for option in listeOptions if option != ""}
    for option, variable in variablesOptions.items():
        tkinter.Checkbutton(sousousframeOptions, text=option, variable=variable, command=verifierChamps, font=police_standard).pack()
    tkinter.Label(sousframe, text="Classes concernées", font=police_standard).grid(row=1, column=1)
    sousousframeClasses = tkinter.Frame(sousframe)
    sousousframeClasses.grid(row=2, column=1)
    variablesClasses = {chr(classe+64): tkinter.BooleanVar() for classe in range(1, EleveContraintes.Eleve.nombreClasses + 1)}
    for classe, variable in variablesClasses.items():
        tkinter.Checkbutton(sousousframeClasses, text=classe, variable=variable, command=verifierChamps, font=police_standard).pack()
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=8, column=0, columnspan=2, padx=10)

def interfaceEquilibreOptionsClasse(frame, textContraintes):
    def verifierChamps(event=None):
        if len([option for option, variable in variablesOptions.items() if variable.get()]) != 0 and len([ord(classe)-64 for classe, variable in variablesClasses.items() if variable.get()]) != 0:
            buttonValidation.config(state="normal")
        else:
            buttonValidation.config(state="disabled")
    def envoiDonnees():
        listeEquilibres.append(EleveContraintes.EquilibreOptionsClasse([option for option, variable in variablesOptions.items() if variable.get()], [ord(classe)-64 for classe, variable in variablesClasses.items() if variable.get()]))
        ajouterBilan(textContraintes, "Equilibrage des options {0} à l'intérieur des classes {1}".format([option for option, variable in variablesOptions.items() if variable.get()], [classe for classe, variable in variablesClasses.items() if variable.get()]), listeEquilibres[-1], listeEquilibres)
        for option, variable in variablesOptions.items():
            variable.set(False)
        for classe, variable in variablesClasses.items():
            variable.set(False)
        verifierChamps()
    sousframe = tkinter.Frame(frame)
    tkinter.Label(sousframe, text="Equilibrer la répartition des options à l'intérieur des classes", font=police_titre).grid(row=0, column=0, columnspan=2)
    tkinter.Label(sousframe, text="Options concernées", font=police_standard).grid(row=1, column=0)
    sousousframeOptions = tkinter.Frame(sousframe)
    sousousframeOptions.grid(row=2, column=0)
    variablesOptions = {option: tkinter.BooleanVar() for option in listeOptions if option != ""}
    for option, variable in variablesOptions.items():
        tkinter.Checkbutton(sousousframeOptions, text=option, variable=variable, command=verifierChamps, font=police_standard).pack()
    tkinter.Label(sousframe, text="Classes concernées", font=police_standard).grid(row=1, column=1)
    sousousframeClasses = tkinter.Frame(sousframe)
    sousousframeClasses.grid(row=2, column=1)
    variablesClasses = {chr(classe+64): tkinter.BooleanVar() for classe in range(1, EleveContraintes.Eleve.nombreClasses + 1)}
    for classe, variable in variablesClasses.items():
        tkinter.Checkbutton(sousousframeClasses, text=classe, variable=variable, command=verifierChamps, font=police_standard).pack()
    buttonValidation = tkinter.Button(sousframe, text="Valider", command=envoiDonnees, font=police_standard, state="disabled")
    buttonValidation.grid(row=3, column=0, columnspan=2)
    tkinter.Label(sousframe, text="", font=police_standard).grid(row=4, column=0, columnspan=2)
    sousframe.grid(row=9, column=0, columnspan=2, padx=10)


def recherche(listeEleves, listeContraintes, listeEquilibres):
    def choisirEleve(listeEleves):
        nonAssignes = [eleve for eleve in listeEleves if eleve.classe == None]
        if nonAssignes == []:
            return None
        else:
            return min(nonAssignes, key=lambda e: len(e.choix))
            # REORDONNER LE CHOIX DES OPTIONS POUR AVOIR LES MEILLEURS CHOIX AU DEBUT / PREVOIR DE QUOI STOPPER LA RECHERCHE SUR UN CLIC DE L'UTILISATEUR
    def calculerScore(listeEleves):
        score = 0
        for equil in listeEquilibres:
            score += equil.calculerScore(listeEleves)
        return score
    def branche(listeEleves, listeContraintes):
        eleve = choisirEleve(listeEleves)
        if eleve is None:
            cns = 0
            for e in listeEleves:
                if e.contrainteNonSatisfaite:
                    cns += 1
            for c in listeContraintes:
                cns += c.cns(listeEleves)
            score = calculerScore(listeEleves)
            if resultat[1] is None or resultat[1] > cns or (resultat[1] == cns and resultat[2] > score):
                resultat[0], resultat[1], resultat[2] = copy.deepcopy(listeEleves), cns, score
        else:
            cns = 0
            for e in listeEleves:
                if e.contrainteNonSatisfaite:
                    cns += 1
            for c in listeContraintes:
                cns += c.cns(listeEleves)
            if resultat[1] is None or resultat[1] > cns or (resultat[1] == cns and resultat[2] > calculerScore(listeEleves)) :
                for i in range(len(eleve.choix)):
                    if continuerRecherche[0]:
                        testerPossibilite(listeEleves, listeContraintes, eleve, eleve.choix[i])
    def testerPossibilite(listeEleves, listeContraintes, eleve, classe):
        sauvEleves, sauvContraintes = [], []
        for e in listeEleves:
            sauvEleves.append({"classe": e.classe, "choix": list(e.choix), "fixe": e.fixe, "contrainteNonSatisfaite": e.contrainteNonSatisfaite})
        for c in listeContraintes:
            sauvContraintes.append(c.effectuee)
        pileExecution = []
        for cl in range(1, EleveContraintes.Eleve.nombreClasses + 1):
            if cl != classe:
                pileExecution += [ctr for ctr in eleve.supprimerChoix(cl, False) if ctr not in pileExecution]
        while pileExecution != []:
            c, pileExecution = pileExecution[0], pileExecution[1:]
            pileExecution += c.appliquer(listeEleves, False)
        branche(listeEleves, listeContraintes)
        for i in range(len(listeEleves)):
            listeEleves[i].classe = sauvEleves[i]["classe"]
            listeEleves[i].choix = sauvEleves[i]["choix"]
            listeEleves[i].fixe = sauvEleves[i]["fixe"]
            listeEleves[i].contrainteNonSatisfaite = sauvEleves[i]["contrainteNonSatisfaite"]
        for i in range(len(sauvContraintes)):
            listeContraintes[i].effectuee = sauvContraintes[i]
    branche(listeEleves, listeContraintes)

def comparerEleves(el1, el2):
    if el1.nom < el2.nom or (el1.nom == el2.nom and el1.prenom <= el2.prenom):
        return -1
    else:
        return 1
listeContraintes = []
listeEquilibres = []
listeEleves, listeOptions = interfaceInitiale()
listeEleves.sort(key=cmp_to_key(comparerEleves))
interfaceContraintes()
resultat = [None, None, None]
continuerRecherche = [True]
pileExecution = list(listeContraintes)
while pileExecution != []:
    c, pileExecution = pileExecution[0], pileExecution[1:]
    for nc in c.appliquer(listeEleves, True):
        if nc not in pileExecution:
            pileExecution.append(nc)
thread = threading.Thread(target=recherche, args=(listeEleves, listeContraintes, listeEquilibres), daemon=True)
thread.start()
interfaceResultat()
